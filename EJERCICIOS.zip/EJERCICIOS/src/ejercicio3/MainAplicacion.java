package ejercicio3;
interface Observer {
 void actualizar(String mensaje);
}
class Usuario implements Observer {
 private String nombre;
 public Usuario(String nombre) {
     this.nombre = nombre;
 }
 public void actualizar(String mensaje) {
     System.out.println(nombre + " recibió: " + mensaje);
 }

}
interface EstrategiaDescuento {
 double calcular(double precio);
}
class SinDescuento implements EstrategiaDescuento {
 public double calcular(double precio) {
     return precio;
 }
}
class DescuentoDiez implements EstrategiaDescuento {
 public double calcular(double precio) {
     return precio * 0.90;
 }
}
class Calculadora {
 private EstrategiaDescuento estrategia;
 public void setEstrategia(EstrategiaDescuento estrategia) {
     this.estrategia = estrategia;
 }
 public double calcularPrecio(double precio) {
     return estrategia.calcular(precio);
 }
}

interface Command {
 void ejecutar();
}
class Compra implements Command {
 private double precio;
 public Compra(double precio) {
     this.precio = precio;
 }
 public void ejecutar() {
     System.out.println("Compra realizada por S/ " + precio);
 }
}
class Tienda {
 private Observer[] usuarios = new Observer[10];
 private int cantidad = 0;
 public void suscribir(Observer usuario) {
     usuarios[cantidad] = usuario;
     cantidad++;
 }
 public void notificar(String mensaje) {
     for (int i = 0; i < cantidad; i++) {
         usuarios[i].actualizar(mensaje);
     }
 }
}
public class MainAplicacion {
 public static void main(String[] args) {
     Tienda tienda = new Tienda();
     Usuario usuario1 = new Usuario("Juan");
     Usuario usuario2 = new Usuario("Pedro");
     tienda.suscribir(usuario1);
     tienda.suscribir(usuario2);
     Calculadora calculadora = new Calculadora();
     double precio = 100;
     calculadora.setEstrategia(new DescuentoDiez());
     double precioFinal = calculadora.calcularPrecio(precio);
     System.out.println("Precio original: S/ " + precio);
     System.out.println("Precio con descuento: S/ " + precioFinal);
     Compra compra = new Compra(precioFinal);
     compra.ejecutar();
     tienda.notificar("Hay una nueva promoción");
 }
}