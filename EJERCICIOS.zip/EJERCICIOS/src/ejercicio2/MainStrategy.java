package ejercicio2;
import java.util.Scanner;
class Producto {
    String nombre;
    double precio;
    public Producto(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }
}
interface EstrategiaDescuento {
    double calcularPrecio(Producto[] productos);
}
class SinDescuento implements EstrategiaDescuento {
    public double calcularPrecio(Producto[] productos) {
        double total = 0;
        for (Producto producto : productos) {
            total = total + producto.precio;
        }
        return total;
    }
}
class DescuentoFijo implements EstrategiaDescuento {
    public double calcularPrecio(Producto[] productos) {
        double total = 0;
        for (Producto producto : productos) {
            total = total + producto.precio;
        }
        return total * 0.90;
    }
}
class DescuentoPorcentual implements EstrategiaDescuento {
    public double calcularPrecio(Producto[] productos) {
        double total = 0;
        for (Producto producto : productos) {
            total = total + producto.precio;
        }
        if (productos.length == 2) {
            return total * 0.70;
        }
        return total;
    }
}
class DescuentoPorcentualAcumulado implements EstrategiaDescuento {
    public double calcularPrecio(Producto[] productos) {
        double total = 0;
        double menor = productos[0].precio;
        for (Producto producto : productos) {
            total = total + producto.precio;
            if (producto.precio < menor) {
                menor = producto.precio;
            }
        }
        if (productos.length >= 3) {
            total = total - (menor * 0.50);
        }
        return total;
    }
}
class CalculadoraDePrecios {
    private EstrategiaDescuento estrategia;
    public void setEstrategia(EstrategiaDescuento estrategia) {
        this.estrategia = estrategia;
    }
    public double calcularPrecio(Producto[] productos) {
        return estrategia.calcularPrecio(productos);
    }
}
public class MainStrategy {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("SISTEMA DE DESCUENTOS");
        System.out.println("1. Sin descuento");
        System.out.println("2. Descuento fijo 10%");
        System.out.println("3. Descuento porcentual 30%");
        System.out.println("4. Descuento acumulado 50%");
        System.out.print("Seleccione una estrategia: ");
        int opcion = entrada.nextInt();
        System.out.print("Ingrese cantidad de productos: ");
        int cantidad = entrada.nextInt();
        Producto[] productos = new Producto[cantidad];
        for (int i = 0; i < cantidad; i++) {
            System.out.println("\nProducto " + (i + 1));

            System.out.print("Ingrese nombre: ");
            String nombre = entrada.next();

            System.out.print("Ingrese precio: ");
            double precio = entrada.nextDouble();

            productos[i] = new Producto(nombre, precio);
        }
        CalculadoraDePrecios calculadora = new CalculadoraDePrecios();
        if (opcion == 1) {
            calculadora.setEstrategia(new SinDescuento());
        } 
        else if (opcion == 2) {
            calculadora.setEstrategia(new DescuentoFijo());
        } 
        else if (opcion == 3) {
            calculadora.setEstrategia(new DescuentoPorcentual());
        } 
        else if (opcion == 4) {
            calculadora.setEstrategia(new DescuentoPorcentualAcumulado());
        } 
        else {
            System.out.println("Opción incorrecta.");
            return;
        }
        double precioFinal = calculadora.calcularPrecio(productos);
        System.out.println("\nPrecio final: S/ " + precioFinal);
    }
}